#include <stdio.h>
#include "system.h"
#include "altera_avalon_pio_regs.h"

int main()
{
	int cont_soft, delay = 0;
	while(1){

		IOWR_ALTERA_AVALON_PIO_DATA(CONTA_BASE, cont_soft);
		delay = 0;
		while(delay < 100000){
			delay++;
		}
		cont_soft++;
	}

  return 0;
}
